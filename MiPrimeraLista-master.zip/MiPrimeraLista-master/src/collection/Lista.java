/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collection;

/**
 *
 * @author laboratorio
 */
public class Lista {

    private Nodo cabeza;
    private Nodo ultimo;
    private int size;

    public Lista() {
        this.cabeza = null;
        this.ultimo = null;
        this.size = 0;
    }

    public Nodo getCabeza() {
        return cabeza;
    }

    public Nodo getUltimo() {
        return ultimo;
    }

    public int size() {
        return size;
    }

    /**
     * <h1>Add</h1>
     * <p>
     * Agrega un elemento al final de la lista.</p>
     *
     * @param data el valor a salvar
     * @return el resultado de la operacion
     */
    public boolean add(int data) {
        if (0 == size) {
            Nodo nuevo = new Nodo(data);
            cabeza = nuevo;
            ultimo = nuevo;
            ++size;
            return true;
        } else {
            Nodo nuevo = new Nodo(data);
            ultimo.setSig(nuevo);
            ultimo = nuevo;
            ++size;
            return true;
        }
    }

    /**
     * 
     * @param index
     * @return 
     */
    public int get(int index) {
        if (0 == size) {
            return -1;
        } else if (index > size) {
            throw new IndexOutOfBoundsException();
        } else if (index == 0){
            return cabeza.getDato();
        } else if (index == size) {
            return ultimo.getDato();
        } else {
            Nodo aux = cabeza;
            int cont = 0;
            
            while (aux.getSig() != null && cont < index) {
                aux = aux.getSig();
                ++cont;
            }
            
            return aux.getDato();
        }
    }
    
    /**
     * 
     * @param index
     * @return 
     */
    public boolean remove(int index) {
        if (index >= 0 && index <= size-1) {
            
            if (0 == index) {
                cabeza = cabeza.getSig();
                
            } else if (size-1 == index) {
                int cont = 0;
                
                Nodo aux = cabeza;
                
                while(cont < index-1) {
                    aux = aux.getSig();
                    ++cont;
                }
                
                aux.setSig(null);
                ultimo = aux;
                
            } else {
                int cont = 0;
                
                Nodo aux = cabeza;
                
                while (cont < index -1) {
                    aux = aux.getSig();
                    ++cont;
                }
                
                aux.setSig(aux.getSig().getSig());
            }
            --size;
            return true;
        } else {
            throw new IndexOutOfBoundsException();
        }
    }
    
    
    
    public boolean addFirst(int data) {
        if (cabeza == null && ultimo == null) {
            Nodo nuevo = new Nodo(data);
            cabeza = nuevo;
            ultimo = nuevo;
            ++size;
            return true;
        }else{
            Nodo nuevo = new Nodo(data);
            nuevo.setSig(cabeza);
            cabeza = nuevo;
            ++size;
            return true;
        }
    }
    
    public int indexOf(int data){
        if(0 == size){
            return -1;
        }else{
            int cont = 0;
            Nodo aux = cabeza;
            while(aux.getSig() != null && cont < size){
                if(aux.getDato() == data){
                   break;
                }
                aux = aux.getSig();
                cont++;
            }
            return cont;
        }
    }
    
    public boolean addIndex(int data, int index){
        if(cabeza == null && ultimo == null){
            return false;
        }else if(index > size || index < 0){
            return false;
        }else if(index == 0){
            Nodo nuevo = new Nodo(data);
            nuevo.setSig(cabeza);
            cabeza = nuevo;
            ++size;
            return true;
        }else if(index == size){
            Nodo nuevo = new Nodo(data);
            ultimo.setSig(nuevo);
            ultimo = nuevo;
            ++size;
            return true;
        }else{
            Nodo nuevo = new Nodo(data);
            Nodo aux = cabeza;
            for (int i = 0; i < (index - 1); i++) {
                aux = aux.getSig();
            }
            Nodo siguiente = aux.getSig();
            aux.setSig(nuevo);
            nuevo.setSig(siguiente);
            size++;
        }
        return true;
    }
    
    public String ToString(){
        Nodo aux = cabeza;
        String lista = "";
        if(size > 0){
            for (int i = 0; i < size; i++) {
            lista += aux.getDato() + ", ";
            aux = aux.getSig();
            }
        }else{
            return "lista vacia";
        }
        
        return lista;
    }
    
    public boolean correrNodos(){
        if (size == 0){
            return false;
        }else{
            int cont = 0;
            Nodo aux = cabeza;
            while(aux.getSig() != null && cont < size){
                if(cont % 2 == 0){
                    aux.setDato(aux.getSig().getDato());
                    aux.getSig().setDato(0);
                }
                aux = aux.getSig();
                cont++;
            }
            return true; 
        }    
    }
    
                            

}